SRB2Stats v1.0 README -- Coded by Michael "Spazzo" Antonakes=
---------------------
Special Thanks: LXShadow for letting me release this as a part of his client-side mod
		Jazz for parsing my pathetic code and cleaning up the formatting
		Mystic/JEV3/Prime_2 for suggestion, advice, and general support throughout.


First off: Hi! Welcome to my little SRB2Stats application!
I coded this little script using C++ (MSVC2010) over the course of a few
drunken nights and weekends.

Throw this application inside of your parent SRB2 dir and execute it
to generate a detailed html and semicolon-delimited txt file containing
all recorded gameplay attributes from match and CTF games (with the exclusion of super sonic,
as his console strings are indistinguishable from invulnerability, and thus can't be recorded)

The following files are created upon execution:
SRB2Stats.html
SRB2Stats.txt

NOTES: This is an early release, so please be warned that stat appending (or inputting '1')
DOES NOT function correctly yet. I hope to have this completely fixed up for next release.

Note that this EXE is *NOT* catered specifically towards LXShadow's mod. In fact, it is exe-
agnostic: feel free to use this on vanilla SRB2 or SRB2CS.

Feel free to import the txt file into excel (being sure to set semicolons as your delimiter)
to create your very own chart, from which you can generate an infinite amount of graphs from
and whatnot.

If you have any issues/problems with running this EXE or any questions in general about it, 
please contact me on AIM/Steam under the "RAWRSpazzo" alias. I'd be happy to help you out. 

Other than that, enjoy! Look forward to the following features in v2.0:

*) Chatlog statistics (Who talks the most? What is your average message length?)
*) Level/round statistics (What level is played the most? How many rounds have you played?)
*) Server-wide statistics (What is the total score of EVERY player? What about total hits?)
*) Player-to-player comparison (Who hit you the most? Who did you hit the most?)

RAWR!
-Spazzo