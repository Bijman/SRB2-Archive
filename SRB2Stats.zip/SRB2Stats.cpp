/*SRB2Stats Application v1.0
	Written entirely within a few drunk nights by Michael "Spazzo" Antonakes, July/11
	Parses log.txt line-by-line and generates SRB2Stats.txt containing neatly organized information about player, score, weapon ring, and chat trends.
	Open the resultant .txt file in Excel and use semicolons (;) as delimiters to access the data in an editable and usable manner.
	My plan is to have the stats output to HTML, using a template table which I've created. There will also be an option to "append" stats.
	Special thanks to Jazz for cleaning up my shoddy code and giving me good advice, and to Mystic/Prime_2 for their helpful suggestions.
	*/

#include <iostream>
#include <string>
#include <stdio.h>
#include <conio.h>
#include <cmath>
#include <cstdlib>
#include <fstream>

using namespace std;

struct user
{
	string nick;
	int score;
	//HITS
	int hits;
	int washit;
	float c_hits;
	//KILLS
	int kills;
	int waskilled;
	int deaths;
	//Includes: Suicides, Enviromental, Bottomless Pits, Crusher, drowning, et al.
	int reflecthits;
	//Hit someone with a reflected projectile. Too insignificant to bother analyzing which weapon it was, just increment every successful hit.
	//int msgs;
	//int kicks;
	//int cfails;
	//TOOK HIT
	int hittypes[9];
	int washittypes[9];
	int totalhits;	//in a perfect world, these shouldn't exist. There's some disparities between "hits" and total weapon ring hits that I can't explain.
	int totalwashits;
	//CTF
	int flagcaptures;
	int flagreturns;
	bool hasflag;
};

bool lolno = false;
user players[65535];

//temporary storage for comparison
string hittypes_t[9] =
{
	"'s ring.",
		"'s automatic ring.",
		"'s scatter ring.",
		"'s bounce ring",
		"'s explosion ring.",
		"'s rail ring.",
		"'s grenade ring.",
		"'s fire trail.",
		"!",	//bahahaha
}
;
string hit_strings[16] =
{
	" was hit by ",
		" was killed by ",
		" died.",
		" fell into a bottomless pit.",
		" suicided.",
		" asphyxiated in space!",
		" fell in some nasty goop!", 
		" burned to death!",
		" was electrocuted!",
		" was impaled by spikes!",
		" drowned.",
		" was crushed.",
		" reflected",
		" was burnt by ",
		" got nuked by ",	//NOTE: Nuke kills are not recorded in SRB2's log as nukes, just as regular kills.
		" was fried by ",
};

string CTF_strings[4] =
{
	" captured the ",
	" returned the ",
	" picked up the ",
	" dropped the ",
};

int playercount = 0;
int overwrite = 0;
string header = "Name; Score; Hits; Was Hit; Reflected Hits; Hit Ratio; Kills; Was Killed; Deaths; Flag Captures; Flag Returns; Red Ring; Auto Ring; Scatter Ring; Bounce Ring; Bomb Ring; Rail Ring; Grenade Ring; Elemental Flames; Nuke; Red Ring Hits; Auto Ring Hits; Scatter Ring Hits; Bounce Ring Hits; Bomb Ring Hits; Rail Ring Hits; Grenade Ring Hits; Elemental Flames; Nuked; ";
int i6 = 1;
int countvar = 0;

void Scoring(string line)
{
	int i;
	bool repeat = false;

	i = line.rfind("Player ");

	if ((i != string::npos))
	{
		i = line.rfind("renamed to ");
		//We want to add a player to our repo if they give us their name. This is how we confirm that.
		if (i != string::npos)
		{
			playercount++;
			line.erase(0, 20);
			i = line.find(" ");

			//Stupid check to remove extra whitespace prefixing the nickname due to player # being > 9.
			if ((i != string::npos) && i == 0)
				line.erase(0, 1);

			for (int i3 = 0; i3 <= playercount; i3++)
			{
				if (players[i3].nick == line)
				{
					//If they're equal, we possess an entry under the same name, and we ignore it.
					playercount--;
					//Comphensation
					repeat = true;
					break;
				}
			}

			if (!(repeat))
				players[playercount].nick = line;

			repeat = false;
		}
	}
	for (int i4 = 0; i4 <= 3; i4++)
	{
		string ctf_tempspace;
		i = line.rfind(CTF_strings[i4]);
		if ((i != string::npos))
		{
			ctf_tempspace.assign(line, 0, i);
			for (int i2 = 0; i2 <= playercount; i2++)
			{
				if (ctf_tempspace.compare(players[i2].nick) == 0)
				{
					if (i4 == 1){
						players[i2].flagcaptures++;
						players[i2].score += 250;
						continue;
					}
					else if (i4 == 2)
					{
						players[i2].flagreturns++;
						players[i2].score += 75;
						continue;
					}
					else if (i4 = 3)
					{
						players[i2].hasflag = true;
						continue;
					}
					else if (i4 = 4)
					{
						players[i2].hasflag = false;
						continue;
					}
				}
			}
		}
	}
	for (int i4 = 0; i4 <= 15; i4++)
	{
		i = line.rfind(hit_strings[i4]);
		string tempspace;
		// hold the nick for comparison
		string tempspace2;
		//hold the name of whoever initially got hit. Hackish, but it works.
		if ((i != string::npos))
		{
			tempspace.assign(line, 0, i);

			for (int i2 = 0; i2 <= playercount; i2++)
			{
				if (tempspace.compare(players[i2].nick) == 0)
				{
					if (line.rfind(hit_strings[12]) <= 100)
					{
						// quick 'n dirty check for reflected hits.
						players[i2].reflecthits++;
						line.erase(0,line.find(hit_strings[12])+10);
						// Remove "reflected" from string
						line.insert(0, "'s");
						// gotta match hittypes_t!
						tempspace.assign(line,0,i);
					}

					//carry on as normal, folks!
					if ((i4 == 0) || (i4 == 13) || (i4 == 14))
						players[i2].washit++; //hit
					else if ((i4 == 1) || (i4 == 15))
						players[i2].waskilled++; 	//kill
					else if ((i4 > 1) && (i4 < 12))
					{
						//suicide/enviromental death
						players[i2].deaths++;
						if (players[i2].score > 0) //No negative scores!
							players[i2].score -=50;
							break; 
						//don't go on and check for weapon rings!
					}
				}
			}

			tempspace2 = tempspace;
			// tempspace 2 = who was hit, tempspace = who hit someone
			if (i4 == 0)
				line.erase(0, i + 12); //hit
			else if (i4 == 1)
				line.erase(0, i + 15); //kill
			else if (i4 >= 13)
				line.erase(0, i + 14); //flameshield/nukeshield
			for (int i3 = 0; i3 <= 8; i3++)
			{
				i = line.find(hittypes_t[i3]);

				//weapon ring options
				if ((i != string::npos))
				{
					tempspace.assign(line, 0, i);

					for (int i2 = 1; i2 <= playercount; i2++)
					{
						if (tempspace.compare(players[i2].nick) == 0)
						{
							//grant points to the attacker, denote weapon ring used
							if ((i4 == 0) || (i4 == 13) || (i4 == 14))
							{
								players[i2].hits++;
								players[i2].hittypes[i3]++;
								players[i2].score += 50;
							} 
							else if ((i4 == 1) || (i4 == 15))
							{
								players[i2].kills++;
								players[i2].hittypes[i3]++;
								players[i2].score += 100;
							}
						}
					}
						for (int i2 = 1; i2 <= playercount; i2++) 					//denote type of weapon ring that hit you.
						{
						if (tempspace2.compare(players[i2].nick) == 0){
							players[i2].washittypes[i3]++;
							break;	}
						}
					
				}
			}
		}
	}
}

bool ReadTextFile()
{
	ifstream txtfile;
	string line;
	string tempspace;
	int i, counter;
	counter = 0;
	txtfile.open("SRB2Stats.txt");

	while (!txtfile.eof())
	{
		getline(txtfile, line);
		lolno = false;

		for (int i2 = 1; i2 <= playercount; i2++)
		{
			i = line.rfind(players[i2].nick);

			if ((i != string::npos))
				line.erase(0, players[i2].nick.length()+2);
		/*	else if (!(i != string::npos) && (!(line == "")))
			{ 
				i = line.find_first_of(";", 0);

				if ((i != string::npos))
				{
					tempspace.assign(line,0,i);

					for (int i8 = 1; i8 <= playercount; i8++)
						if (tempspace == players[i8].nick)
							lolno = true;

					if (lolno == false)
					{
						playercount++;
						players[playercount].nick.assign(line,0,i);
						line.erase(0, players[playercount].nick.length()+2);
					}
				}

				break; 
			}*/

			for (int i3 = 1; i3 <= 28; i3++) 
			{
				counter++;

				if (!(counter == 1))
					line.erase(0, tempspace.length()+2);

				i = line.find_first_of(";", 0);

				if ((i != string::npos))
				{
					tempspace.assign(line,0,i);

					switch (counter)
					{
						case 1:
							players[i2].score += atoi(tempspace.c_str());
							continue;
						case 2:
							players[i2].hits += atoi(tempspace.c_str());
							continue;
						case 3:
							players[i2].washit += atoi(tempspace.c_str());
							continue;
						case 4:
							players[i2].reflecthits += atoi(tempspace.c_str());
							continue;
						case 5:
							if (!(players[i].washit == 0))
									players[i].c_hits = float(players[i].hits) / float(players[i].washit);
							else
									players[i].c_hits = float(players[i].hits);
							continue;
						case 6:
							players[i2].kills += atoi(tempspace.c_str());
							continue;
						case 7:
							players[i2].waskilled += atoi(tempspace.c_str());
							continue;
						case 8:
							players[i2].deaths += atoi(tempspace.c_str());
							continue;
						case 9:
							players[i2].flagcaptures += atoi(tempspace.c_str());
							continue;
						case 10:
							players[i2].flagreturns += atoi(tempspace.c_str());
							continue;
						case 11:
							players[i2].hittypes[0] += atoi(tempspace.c_str());
							continue;
						case 12:
							players[i2].hittypes[1] += atoi(tempspace.c_str());
							continue;
						case 13:
							players[i2].hittypes[2] += atoi(tempspace.c_str());
							continue;
						case 14:
							players[i2].hittypes[3] += atoi(tempspace.c_str());
							continue;
						case 15:
							players[i2].hittypes[4] += atoi(tempspace.c_str());
							continue;
						case 16:
							players[i2].hittypes[5] += atoi(tempspace.c_str());
							continue;
						case 17:
							players[i2].hittypes[6] += atoi(tempspace.c_str());
							continue;
						case 18:
							players[i2].hittypes[7] += atoi(tempspace.c_str());
							continue;
						case 19:
							players[i2].hittypes[8] += atoi(tempspace.c_str());
							continue;
						case 20:
							players[i2].washittypes[0] += atoi(tempspace.c_str());
							continue;
						case 21:
							players[i2].washittypes[1] += atoi(tempspace.c_str());
							continue;
						case 22:
							players[i2].washittypes[2] += atoi(tempspace.c_str());
							continue;
						case 23:
							players[i2].washittypes[3] += atoi(tempspace.c_str());
							continue;
						case 24:
							players[i2].washittypes[4] += atoi(tempspace.c_str());
							continue;
						case 25:
							players[i2].washittypes[5] += atoi(tempspace.c_str());
							continue;
						case 26:
							players[i2].washittypes[6] += atoi(tempspace.c_str());
							continue;
						case 27:
							players[i2].washittypes[7] += atoi(tempspace.c_str());
							continue;
						case 28:
							players[i2].washittypes[8] += atoi(tempspace.c_str());
							counter = 0;
							continue;
					}
				}
			}
		}
	}

	txtfile.close();
	return true;
}

bool ReadVar()
{
	string line;
	ifstream infile;
	infile.open("log.txt");

	while ((!infile.eof()) && (line != "I_Quit(): end of logstream."))
	{
		getline(infile, line);
		//read a line...
		Scoring(line);
	}

	infile.close();
	return true;
}
void WriteVar()
{
	ofstream outfile;
	outfile.open("SRB2Stats.txt");
//	outfile << header << endl;

	for (int i = 1; i <= playercount; i++)
	{
		if ((players[i].score == 0) && (players[i].hits == 0) && (players[i].washit == 0) && (players[i].kills == 0) && (players[i].waskilled == 0) && (players[i].deaths == 0))
			continue;
		if (!(players[i].washit == 0))
			players[i].c_hits = float(players[i].hits) / float(players[i].washit);
		else
			players[i].c_hits = float(players[i].hits);
		outfile << players[i].nick << "; ";
		outfile << players[i].score << "; ";
		outfile << players[i].hits << "; ";
		outfile << players[i].washit << "; ";
		outfile << players[i].reflecthits << "; ";
		outfile.precision(4);
		outfile << players[i].c_hits << "; ";
		outfile.precision(0);
		outfile << players[i].kills << "; ";
		outfile << players[i].waskilled << "; ";
		outfile << players[i].deaths << "; ";
		outfile << players[i].flagcaptures << "; ";
		outfile << players[i].flagreturns << "; ";
		for (int i2 = 0; i2 <= 8; i2++){
			if (!(players[i].hittypes[i2] == 0) && (i2 <=6) )
			{
				outfile.precision(2);
				outfile << ((players[i].hits - players[i].reflecthits) / players[i].hittypes[i2]) << "%; ";
				outfile.precision(0);
			}
			else if (i2 > 6)
			outfile << players[i].hittypes[i2] << "; "; }
		for (int i2 = 0; i2 <= 8; i2++){
			if (!(players[i].washittypes[i2] == 0) && (i2 <=6) )
			{
				outfile.precision(2);
				outfile << (players[i].washit / players[i].washittypes[i2]) << "%; ";
				outfile.precision(0);
			}
			else if (i2 > 6)
			outfile << players[i].washittypes[i2] << "; "; }
		outfile << "" <<endl;

	}
		outfile.close();
}

void ExportHTML(){
	ofstream outfile;
	outfile.open("SRB2Stats.html");
	outfile << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">" << endl;
	outfile << "<html xmlns=\"http://www.w3.org/1999/xhtml\">" << endl;
	outfile << "<head>" << endl;
	outfile << "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />" << endl;
	outfile << "<title>SRB2 -- Statistics</title>" << endl;
	outfile << "</head>" << endl;
	outfile << "<body>" << endl;
	outfile << "<table width=\"50\" border=\"2\">" << endl;
	outfile << "<tr>" << endl;
    outfile << "<th colspan=\"11\" scope=\"col\">Player Info.</th>" << endl;
	outfile << "<th colspan=\"9\" bgcolor=\"#009900\" scope=\"col\"><strong>Hits Given</strong></th>" << endl;
    outfile << "<th colspan=\"9\" bgcolor=\"#990000\" scope=\"col\">Hits Taken</th>" << endl;
	outfile << "</tr>" << endl;
	outfile << "<tr>" << endl;
    outfile << "<th height=\"48\" scope=\"col\">Name</th>" << endl;
    outfile << "<th scope=\"col\">Score</th>" << endl;
    outfile << "<th scope=\"col\">Hits</th>" << endl;
    outfile << "<th scope=\"col\">Was Hit</th>" << endl;
    outfile << "<th scope=\"col\">Reflect Hits</th>" << endl;
    outfile << "<th scope=\"col\">Hit Ratio</th>" << endl;
    outfile << "<th scope=\"col\">Kills</th>" << endl;
    outfile << "<th scope=\"col\">Was Killed</th>" << endl;
    outfile << "<th scope=\"col\">Deaths</th>" << endl;
    outfile << "<th scope=\"col\">Flag Captures</th>" << endl;
    outfile << "<th scope=\"col\">Flag Returns</th>" << endl;
    outfile << "<td><img src=\"media/wpanel_red.png\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_auto.png\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_scatter.png\" width=\"40\" height=\"42\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_bounce.png\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_explosion.png\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_rail.png\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_grenade.png\" width=\"40\" height=\"42\" /></td>" << endl;
    outfile << "<td><img src=\"media/elemental.png\" width=\"34\" height=\"40\" /></td>" << endl;
    outfile << "<td><img src=\"media/bomb.png\" width=\"34\" height=\"40\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpanel_red.png\" alt=\"\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_auto.png\" alt=\"\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_scatter.png\" alt=\"\" width=\"40\" height=\"42\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_bounce.png\" alt=\"\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_explosion.png\" alt=\"\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_rail.png\" alt=\"\" width=\"40\" height=\"44\" /></td>" << endl;
    outfile << "<td><img src=\"media/wpnpanel_grenade.png\" alt=\"\" width=\"40\" height=\"42\" /></td>" << endl;
    outfile << "<td><img src=\"media/elemental.png\" alt=\"\" width=\"34\" height=\"40\" /></td>" << endl;
    outfile << "<td><img src=\"media/bomb.png\" alt=\"\" width=\"34\" height=\"40\" /></td>" << endl;
	outfile << "</tr>" << endl;
	for (int i5 = 1; i5 <= playercount; i5++){
		if ((players[i5].score == 0) && (players[i5].hits == 0) && (players[i5].washit == 0) && (players[i5].kills == 0) && (players[i5].waskilled == 0) && (players[i5].deaths == 0))
			continue;
	outfile << "<tr>" << endl;
    outfile << "<th nowrap=\"nowrap\" scope=\"row\">" << players[i5].nick << " </th>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].score << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].hits << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].washit << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].reflecthits << "</td>" << endl;
		outfile.precision(3);
		outfile << "<td align =\"middle\">" << players[i5].c_hits << "</td>" << endl;
		outfile.precision(0);
		outfile << "<td align =\"middle\">" << players[i5].kills << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].waskilled << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].deaths << "</td>" << endl;
		outfile << "<td align =\"middle\">" << players[i5].flagcaptures << "</td>" << endl;
		outfile << " <td align =\"middle\">" << players[i5].flagreturns << "</td>" << endl;
		for (int i2 = 0; i2 <= 8; i2++){
			if ((players[i5].hittypes[i2] == 0) && (i2 < 7))
			{
				outfile << "<td align =\"middle\">0%</td>" << endl;
			continue;
			} else if ((players[i5].hittypes[i2] == players[i5].totalhits) && (i2 < 7))
			{
				outfile << "<td align =\"middle\">100%</td>" << endl;
			continue;
			}
			if (i2 < 7)
			{
				outfile.precision(2);
				outfile << "<td align =\"middle\">" << ((float(players[i5].hittypes[i2]) / float(players[i5].totalhits)) * 100) << "%</td>" << endl;
				outfile.precision(0);
			}
			else if (i2 > 6)
			outfile << "<td align =\"middle\">" << players[i5].hittypes[i2] << "</td>" << endl; }
		for (int i2 = 0; i2 <= 8; i2++){
				if ((players[i5].washittypes[i2] == 0) && (i2 < 7))
			{
				outfile << "<td align =\"middle\">0%</td>" << endl;
			continue;
			} else if ((players[i5].washittypes[i2] == players[i5].totalwashits)  && (i2 < 7))
			{
				outfile << "<td align =\"middle\">100%</td>" << endl;
			continue;
			}
			if (i2 < 7)
			{
				outfile.precision(2);
				outfile << "<td align =\"middle\">" << ((float(players[i5].washittypes[i2]) / float(players[i5].totalwashits)) * 100) << "%</td>" << endl;
				outfile.precision(0);
			}
			else if (i2 > 6)
			outfile << "<td align =\"middle\">" << players[i5].washittypes[i2] << "</td>" << endl; }
		outfile << "</tr>" << endl;
	}
	outfile << "</table>" << endl;
	outfile << "</body>" << endl;
	outfile << "</html>" << endl;
	outfile.close();
}


int main()
{
	//Really just stat output for now. Will put this in seperate function sometime later.

	cout<<"Welcome to Spazzo's SRB2Stats Generator!" << endl;
	cout<<"----------------------------------------" << endl;
	cout<<"Please make sure this exe is within SRB2's parent directory." << endl;
	cout<<"Would you like this log to add on to existing stats? (0/1)" << endl;
	cin >> overwrite;
	cout<<"Working..." << endl;
	ReadVar();

	if (overwrite == 1)
		ReadTextFile();
	for (int i5 = 1; i5 <= playercount; i5++)
	{
		for (int i4 = 0; i4 <= 6; i4++)
		{
			players[i5].totalhits += players[i5].hittypes[i4];
			players[i5].totalwashits += players[i5].washittypes[i4];
		}
		players[i5].hits = players[i5].totalhits + players[i5].hittypes[7] + players[i5].hittypes[8];
		players[i5].washit = players[i5].totalwashits + players[i5].washittypes[7] + players[i5].washittypes[8];
	}
	WriteVar();
	//if (overwrite == 1)
		//ExportHTML_append();
	//else
		ExportHTML();
	return 0;
}